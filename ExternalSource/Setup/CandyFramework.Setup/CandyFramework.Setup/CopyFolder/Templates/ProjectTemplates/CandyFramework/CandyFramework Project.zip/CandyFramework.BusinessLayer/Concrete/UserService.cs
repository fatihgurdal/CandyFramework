﻿using $safeprojectname$.Interface;
using $ext_projectname$.Entity.Entity.ViewModel;
using $ext_projectname$.DataAccessLayer.Interface;
using $ext_projectname$.Core.Concrete.Common;
using $ext_projectname$.Entity.Entity.Entity;

namespace $safeprojectname$.Concrete
{
    public class UserService : BaseService<UserEntity, UserView>, IUserService
    {
        #region - Repository -
        private readonly IUserRepository userRepository;
        #endregion
        public UserService(IUserRepository _userRepository) : base(_userRepository)
        {
            userRepository = _userRepository;
        }

        public UserView GetUserByPassword(string userName, string password)
        {
            return userRepository.GetUserByPassword(userName, password).Map();
        }

        public bool UserNamePasswordControl(string userName, string password)
        {
            return userRepository.UserNamePasswordControl(userName, password);
        }
    }
}
