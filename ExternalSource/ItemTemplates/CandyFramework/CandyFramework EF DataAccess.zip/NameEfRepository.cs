﻿using $rootnamespace$.DataAccessLayer.Concrete.EntityFramework.Base;
using $rootnamespace$.DataAccessLayer.Concrete.EntityFramework.Context;
using $rootnamespace$.DataAccessLayer.Interface;
using $rootnamespace$.Entity.Entity.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$.DataAccessLayer.Concrete.EntityFramework
{
    public class $basename$EfRepository : EntityFrameworkRepository<$basename$Entity, $rootnamespace$Context>, I$basename$Repository
    {
        public $basename$EfRepository()
        {

        }
    }
}
