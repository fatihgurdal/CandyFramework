﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Enum
{
    public enum DbStateEnum : int
    {
        Active = 0,
        Passive = 1,
        Deleted = 2
    }
}
