﻿using $ext_projectname$.Core.Interface.Entity;
using $safeprojectname$.Entity.Entity;
using $safeprojectname$.Interface.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Interface.Entity
{
    public interface IUserEntity : IUser, ICreateEntity, IUpdateEntity, IEntity
    {
        string Password { get; set; }
        byte[] ProfilPhoto { get; set; }
        UserGroupEntity UserGroup { get; set; }
    }
}
