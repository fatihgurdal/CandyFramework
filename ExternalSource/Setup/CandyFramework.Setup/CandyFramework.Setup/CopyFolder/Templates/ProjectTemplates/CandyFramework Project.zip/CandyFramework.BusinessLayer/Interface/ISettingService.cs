﻿using CandyFramework.Core.Interface.BusinessLayer;
using CandyFramework.Entity.Entity.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Interface
{
    public interface ISettingService : IBaseService<SettingView>
    {
        void LoadSettings();
    }
}
