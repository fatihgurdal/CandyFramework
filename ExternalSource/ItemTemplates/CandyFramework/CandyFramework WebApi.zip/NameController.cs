﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Web.Http;

namespace $rootnamespace$.Controllers
{
    public class $basename$Controller : BaseController
    {
        private readonly I$basename$Service _$basename$Service;
        public $basename$Controller(I$basename$Service $basename$Service)
        {
            _$basename$Service = $basename$Service;
        }
        [HttpGet]
        public IHttpActionResult Gets()
        {
            var list = new List<string>() { "Value1", "Value2", "Value3" };
            return Ok(_$basename$Service.All());
        }
    }
}
