﻿using $safeprojectname$.Entity.ViewModel;
using $safeprojectname$.Interface.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Interface.ViewModel
{
    public interface IUserGroupView : IUserGroup
    {
        ICollection<UserView> Users { get; set; }
    }
}
