﻿using $safeprojectname$.Concrete.EntityFramework.Base;
using $safeprojectname$.Concrete.EntityFramework.Context;
using $safeprojectname$.Interface;
using CandyFramework.Entity.Entity.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Concrete.EntityFramework
{
    public class SettingEfRepository : EntityFrameworkRepository<SettingEntity, CandyContext>, ISettingRepository
    {
        public SettingEfRepository()
        {

        }
        public override void Add(List<SettingEntity> entities)
        {
            throw new NotSupportedException("Setting Tablosuna kayıt eklenemez.");
        }
        public override void Add(SettingEntity entity)
        {
            throw new NotSupportedException("Setting Tablosuna kayıt eklenemez.");
        }
        public override void Delete(IEnumerable<SettingEntity> entities)
        {
            throw new NotSupportedException("Setting Tablosuna kayıt eklenemez.");
        }
        public override void Delete(SettingEntity entity)
        {
            throw new NotSupportedException("Setting Tablosuna kayıt eklenemez.");
        }
    }
}
