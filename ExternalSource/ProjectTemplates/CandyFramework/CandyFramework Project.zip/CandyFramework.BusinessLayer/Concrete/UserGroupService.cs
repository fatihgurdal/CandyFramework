﻿using $safeprojectname$.Interface;
using $ext_projectname$.DataAccessLayer.Interface;
using $ext_projectname$.Entity.Entity.Entity;
using $ext_projectname$.Entity.Entity.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Concrete
{
    public class UserGroupService: BaseService<UserGroupEntity, UserGroupView>, IUserGroupService
    {
        #region - Repository -
        private readonly IUserGroupRepository UserGroupRepository;
        #endregion
        public UserGroupService(IUserGroupRepository _UserGroupRepository) : base(_UserGroupRepository)
        {
            UserGroupRepository = _UserGroupRepository;
        }
    }
}
