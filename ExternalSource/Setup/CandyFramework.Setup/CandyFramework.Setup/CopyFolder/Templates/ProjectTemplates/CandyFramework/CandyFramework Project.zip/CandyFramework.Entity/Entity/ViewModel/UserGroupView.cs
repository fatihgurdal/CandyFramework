﻿using $ext_projectname$.Core.Enum;
using $ext_projectname$.Core.Interface.Entity;
using $safeprojectname$.Entity.Entity;
using $safeprojectname$.Interface.ViewModel;
using Mapster;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Entity.ViewModel
{
    public class UserGroupView : Base.UserGroup, IUserGroupView, IViewMap<UserGroupEntity>
    {
        public UserGroupView()
        {

        }

        public ICollection<UserView> Users { get; set; }

        public UserGroupEntity Map()
        {
            var result = this.Adapt<UserGroupEntity>();

            return result;
        }
    }
}
