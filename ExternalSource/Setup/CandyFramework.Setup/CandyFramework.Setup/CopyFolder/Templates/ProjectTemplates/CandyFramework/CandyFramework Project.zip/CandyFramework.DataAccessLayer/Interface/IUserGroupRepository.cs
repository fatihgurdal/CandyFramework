﻿using $ext_projectname$.Core.Interface.DataAccess;
using $ext_projectname$.Entity.Entity.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Interface
{
    public interface IUserGroupRepository : IRepository<UserGroupEntity>
    {
    }
}
