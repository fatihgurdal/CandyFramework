﻿using CandyFramework.Core.Interface.Entity;
using $safeprojectname$.Entity.Entity;
using $safeprojectname$.Interface.Base;

namespace $safeprojectname$.Interface.Entity
{
    public interface IUserEntity : IUser, ICreateEntity, IUpdateEntity, IEntity
    {
        string Password { get; set; }
        byte[] ProfilPhoto { get; set; }
        UserGroupEntity UserGroup { get; set; }
    }
}
