﻿using $ext_projectname$.Core.Interface.Entity;
using $safeprojectname$.Entity.ViewModel;
using $safeprojectname$.Interface.Entity;
using Mapster;
using System;

namespace $safeprojectname$.Entity.Entity
{
    public class SettingEntity : Base.Setting, ISettingEntity, IEntityMap<SettingView>
    {
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string UpdateUser { get; set; }
        public DateTime UpdateDate { get; set; }

        public SettingEntity()
        {

        }
        public SettingView Map()
        {
            var result = this.Adapt<SettingView>();

            return result;
        }
    }
}
