﻿using $ext_projectname$.Core.Enum;
using $ext_projectname$.Core.Interface.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Interface.Base
{
    public interface ICandyLog : ICreateEntity, IKeyEntity, IEntity
    {
        CandyLogType Type { get; set; }
        string ErrorMessage { get; set; }
        string ErrorDetail { get; set; }
        string InnerException { get; set; }
        int Level { get; set; }
    }
}
