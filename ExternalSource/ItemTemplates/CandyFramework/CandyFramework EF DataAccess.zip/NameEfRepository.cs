﻿using $rootnamespace$.Concrete.EntityFramework.Base;
using $rootnamespace$.Concrete.EntityFramework.Context;
using $rootnamespace$.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$.Concrete.EntityFramework
{
    public class $basename$EfRepository : EntityFrameworkRepository<$basename$Entity, CandyContext>, I$basename$Repository
    {
        public $basename$EfRepository()
        {

        }
    }
}
