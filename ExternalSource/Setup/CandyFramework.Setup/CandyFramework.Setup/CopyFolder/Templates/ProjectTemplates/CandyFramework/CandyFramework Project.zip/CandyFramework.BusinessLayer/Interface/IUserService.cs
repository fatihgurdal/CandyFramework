﻿using $ext_projectname$.Core.Interface.BusinessLayer;
using $ext_projectname$.Entity.Entity.ViewModel;

namespace $safeprojectname$.Interface
{
    public interface IUserService: IBaseService<UserView>
    {
        bool UserNamePasswordControl(string userName, string password);
        UserView GetUserByPassword(string userName, string password);
    }
}
