﻿using $rootnamespace$.Core.Interface.DataAccess;
using $rootnamespace$.Entity.Entity.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$.DataAccessLayer.Interface
{
    public interface I$basename$Repository : IRepository<$basename$Entity>
    {
    }
}
