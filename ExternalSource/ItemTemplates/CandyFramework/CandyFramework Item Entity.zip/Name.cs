﻿using $rootnamespace$.Core.Enum;
using $rootnamespace$.Entity.Interface.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$.Entity.Base
{
    public abstract class $basename$ : I$basename$
    {
        public int Id { get; set; }
        public DbStateEnum State { get; set; }
    }
}
