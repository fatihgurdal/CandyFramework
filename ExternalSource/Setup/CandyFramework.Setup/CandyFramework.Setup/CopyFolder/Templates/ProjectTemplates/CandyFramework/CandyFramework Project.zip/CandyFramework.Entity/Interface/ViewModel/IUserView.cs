﻿using $safeprojectname$.Entity.ViewModel;
using $safeprojectname$.Interface.Base;

namespace $safeprojectname$.Interface.ViewModel
{
    public interface IUserView : IUser
    {
        string ProfilPhotoBase64 { get; set; }
        string FullName { get; set; }
        string UserGroupName { get; set; }
        UserGroupView UserGroup { get; set; }
    }
}
