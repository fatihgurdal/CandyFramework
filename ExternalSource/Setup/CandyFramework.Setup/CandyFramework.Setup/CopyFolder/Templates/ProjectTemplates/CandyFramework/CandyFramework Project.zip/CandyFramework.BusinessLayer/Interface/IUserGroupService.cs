﻿using $ext_projectname$.Core.Interface.BusinessLayer;
using $ext_projectname$.Entity.Entity.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Interface
{
    public interface IUserGroupService : IBaseService<UserGroupView>
    {
    }
}
