﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Interface.Entity
{
    public interface IKeyEntity
    {
        int Id { get; set; }
    }
}
