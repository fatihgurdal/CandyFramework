﻿using $safeprojectname$.Concrete.EntityFramework.Base;
using $safeprojectname$.Concrete.EntityFramework.Context;
using $safeprojectname$.Interface;
using CandyFramework.Entity.Entity.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Concrete.EntityFramework
{
    public class UserGroupEfRepository : EntityFrameworkRepository<UserGroupEntity, CandyContext>, IUserGroupRepository
    {
        public UserGroupEfRepository()
        {

        }
    }
}
