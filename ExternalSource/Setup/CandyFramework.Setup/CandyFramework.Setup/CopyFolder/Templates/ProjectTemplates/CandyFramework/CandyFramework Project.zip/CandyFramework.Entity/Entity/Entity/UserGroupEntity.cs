﻿using $ext_projectname$.Core.Enum;
using $ext_projectname$.Core.Interface.Entity;
using $safeprojectname$.Entity.ViewModel;
using $safeprojectname$.Interface.Entity;
using $safeprojectname$.Interface.ViewModel;
using Mapster;
using System;
using System.Collections.Generic;

namespace $safeprojectname$.Entity.Entity
{
    public class UserGroupEntity : Base.UserGroup, IUserGroupEntity, IEntityMap<UserGroupView>
    {
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string UpdateUser { get; set; }
        public DateTime UpdateDate { get; set; }

        public virtual ICollection<UserEntity> Users { get; set; } = new HashSet<UserEntity>();

        public UserGroupEntity()
        {

        }
        public UserGroupView Map()
        {
            var result = this.Adapt<UserGroupView>();

            return result;
        }
    }
}
