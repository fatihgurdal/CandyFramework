﻿using $ext_projectname$.BusinessLayer.Concrete;
using $ext_projectname$.BusinessLayer.Interface;
using $ext_projectname$.Core.Concrete.Common;
using $ext_projectname$.Core.Concrete.Core;
using $ext_projectname$.Core.Interface.Application;
using $ext_projectname$.Core.Interface.Core;
using $ext_projectname$.DataAccessLayer.Concrete.EntityFramework;
using $ext_projectname$.DataAccessLayer.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Bootstrappers
{
    /// <summary>
    /// Dependency bootstrapper
    /// </summary>
    public class DependencyBootstrapper : IBootstrapper
    {
        /// <summary>
        /// Bootstraps dependencies
        /// </summary>
        /// <param name="dependencyContainer"></param>
        public virtual void Bootstrap(IDependencyContainer dependencyContainer)
        {
            //dependencyContainer.RegisterTransient<ILogger, Logger>();

            //User Table için dependency injection
            dependencyContainer.RegisterTransient<IUserService, UserService>();
            dependencyContainer.RegisterTransient<IUserRepository, UserEfRepository>();

            dependencyContainer.RegisterTransient<ISettingService, SettingService>();
            dependencyContainer.RegisterTransient<ISettingRepository, SettingEfRepository>();

            dependencyContainer.RegisterTransient<IUserGroupService, UserGroupService>();
            dependencyContainer.RegisterTransient<IUserGroupRepository, UserGroupEfRepository>();


        }
    }
}
