﻿using $rootnamespace$.Entity.ViewModel;
using $rootnamespace$.Interface.Entity;
using $rootnamespace$.Interface.ViewModel;
using Mapster;
using System;

namespace $rootnamespace$.Entity.Entity
{
    public class $basename$Entity : Base.$basename$, I$basename$Entity, IEntityMap<$basename$View>
    {
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string UpdateUser { get; set; }
        public DateTime UpdateDate { get; set; }

        public $basename$Entity()
        {

        }
        public $basename$View Map()
        {
            var result = this.Adapt<$basename$View>();

            return result;
        }
    }
}
