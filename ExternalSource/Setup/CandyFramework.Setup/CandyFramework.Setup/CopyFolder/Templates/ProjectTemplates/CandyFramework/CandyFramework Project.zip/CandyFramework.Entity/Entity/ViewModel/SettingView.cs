﻿using $ext_projectname$.Core.Interface.Entity;
using $safeprojectname$.Entity.Entity;
using $safeprojectname$.Interface.ViewModel;
using Mapster;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Entity.ViewModel
{
    public class SettingView : Base.Setting, ISettingView, IViewMap<SettingEntity>
    {
        public SettingView()
        {

        }
        public SettingEntity Map()
        {
            var result = this.Adapt<SettingEntity>();

            return result;
        }
    }
}
