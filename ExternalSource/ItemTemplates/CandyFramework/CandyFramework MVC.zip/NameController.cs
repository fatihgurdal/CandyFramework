﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace $rootnamespace$.MVC.Controllers
{
    [ErrorFilterAttiribute]
    public class AccountController : BaseController
    {
        private readonly I$basename$Service _$basename$Service;
        public AccountController(I$basename$Service $basename$Service)
        {
            _$basename$Service = $basename$Service;
        }
        public ActionResult Index()
        {
            return View();
        }
    }
}
