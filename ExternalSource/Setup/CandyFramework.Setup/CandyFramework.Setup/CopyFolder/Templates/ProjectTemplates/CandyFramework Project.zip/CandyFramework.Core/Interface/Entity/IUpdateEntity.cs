﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Interface.Entity
{
    public interface IUpdateEntity
    {
        string UpdateUser { get; set; }
        DateTime UpdateDate { get; set; }
    }
}
