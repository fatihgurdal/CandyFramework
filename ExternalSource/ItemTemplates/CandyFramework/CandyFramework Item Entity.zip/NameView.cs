﻿using $rootnamespace$.Entity.Entity;
using $rootnamespace$.Interface.ViewModel;
using Mapster;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$.Entity.ViewModel
{
    public class $basename$View : Base.$basename$, I$basename$View, IViewMap<$basename$Entity>
    {
        public $basename$View()
        {

        }
        public $basename$Entity Map()
        {
            var result = this.Adapt<$basename$Entity>();

            return result;
        }
    }
}
