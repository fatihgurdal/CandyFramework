﻿using $safeprojectname$.Entity.ViewModel;
using $safeprojectname$.Interface.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Interface.ViewModel
{
    public interface IUserView : IUser
    {
        string ProfilPhotoBase64 { get; set; }
        string FullName { get; set; }
        UserGroupView UserGroup { get; set; }
    }
}
