﻿using $rootnamespace$.Entity.Entity;
using $rootnamespace$.Interface.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$.Interface.Entity
{
    public interface I$basename$Entity : I$basename$, ICreateEntity, IUpdateEntity, IEntity
    {
    }
}
