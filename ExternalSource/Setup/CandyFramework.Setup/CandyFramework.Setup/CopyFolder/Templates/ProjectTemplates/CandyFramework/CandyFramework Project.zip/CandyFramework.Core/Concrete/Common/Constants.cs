﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Concrete.Common
{
    public class Constants
    {
        internal const string EncryptionPassword = "JbW4cabZfuFkxAqT";
    }
}
