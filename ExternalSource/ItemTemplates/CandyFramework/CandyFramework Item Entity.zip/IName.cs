﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$.Interface.Base
{
    public interface I$basename$ : IKeyEntity, IState
    {
    }
}
