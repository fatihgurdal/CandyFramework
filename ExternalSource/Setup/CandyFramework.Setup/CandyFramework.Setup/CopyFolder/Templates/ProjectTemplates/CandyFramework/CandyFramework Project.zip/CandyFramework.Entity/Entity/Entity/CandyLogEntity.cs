﻿using $ext_projectname$.Core.Interface.Entity;
using $safeprojectname$.Entity.Base;
using $safeprojectname$.Entity.ViewModel;
using Mapster;

namespace $safeprojectname$.Entity.Entity
{
    public class CandyLogEntity : CandyLog, IEntityMap<CandyLogView>
    {

        #region - Entity Map -
        public CandyLogView Map()
        {
            var result = this.Adapt<CandyLogView>();
            return result;
        } 
        #endregion
    }
}
