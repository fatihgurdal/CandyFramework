﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$.BusinessLayer.Concrete
{
    public class $basename$Service : BaseService<$basename$Entity, $basename$View>, I$basename$Service
    {
        #region - Repository -
        private readonly I$basename$Repository $basename$Repository;
        #endregion
        public $basename$Service(I$basename$Repository _$basename$Repository) : base(_$basename$Repository)
        {
            $basename$Repository = _$basename$Repository;
        }
    }
}
