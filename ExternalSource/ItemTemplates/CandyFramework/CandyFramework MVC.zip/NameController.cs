﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using $rootnamespace$.Attiribute;
namespace $rootnamespace$.Controllers
{
    [ErrorFilterAttiribute]
    public class $basename$Controller : BaseController
    {
        private readonly I$basename$Service _$basename$Service;
        public $basename$Controller(I$basename$Service $basename$Service)
        {
            _$basename$Service = $basename$Service;
        }
        public ActionResult Index()
        {
            return View();
        }
    }
}
